﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExample
{
    class Program
    {
        static List<Employee> lstEmp = new List<Employee>();
        static List<Department> lstDept = new List<Department>();

        //SELECT with 3 variations
        static void Main1(string[] args)
        {
            //SELECT statement

            AddRecs();

            //Only one column is selected 
            var emps1 = from emp in lstEmp select emp;
            foreach (var emp in emps1)
            {
                Console.WriteLine(emp.Name);
            }
            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();



            //Only one column is selected 
            var emps2 = from emp in lstEmp select emp.Name;
            foreach (var emp in emps2)
            {
                Console.WriteLine(emp);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();


            //More than one column is selected then return type is anonymous
            var emps = from emp in lstEmp select new { emp.Name, emp.Basic, emp.DeptNo };
            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name +", " +emp.Basic + ", " +emp.DeptNo);
            }

           
        
            
        }

        //WHERE Clause
        static void Main2() {

            AddRecs();

            //First Where clause
            var emps = from emp in lstEmp
                       where emp.Name.StartsWith("S")
                       select emp;

            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();


            var emps4 = from emp in lstEmp
                        where emp.Basic > 10000 && emp.Basic < 12000
                        select emp;
            foreach (var emp in emps4) {
                Console.WriteLine(emp.Name+ ", " +emp.Basic);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();


            var emps1 = from emp in lstEmp
                        where emp.Basic > 10000
                        select emp;
            foreach (var emp in emps1)
            {
                Console.WriteLine(emp.Name + " " +emp.Basic);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            var emps2 = from emp in lstEmp
                        where emp.DeptNo > 10 && emp.DeptNo < 30
                        select emp;
            foreach (var emp in emps2) {
                Console.WriteLine(emp.Name+ ", " +emp.DeptNo);
            }

        }


        //ORDERBY Clause
        static void Main3() {
            AddRecs();

            var emps1 = from emp in lstEmp
                       where emp.Basic > 10000
                       orderby emp.DeptNo descending
                       select emp;
            foreach (var emp in emps1) {
                Console.WriteLine(emp.Name+ ", " +emp.Basic+ ", " +emp.DeptNo);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            var emps2 = from emp1 in lstEmp
                        where emp1.DeptNo > 10
                        orderby emp1.Name, emp1.Basic
                        select emp1;

            foreach (var emp in emps2)
            {
                Console.WriteLine(emp.Name + ", " + emp.Basic + ", " + emp.DeptNo);
            }


        }

        //JOINS
        static void Main4() {
            AddRecs();

            
            var emps1 = from emp in lstEmp
                        join
                        dept in lstDept
                        on emp.DeptNo equals dept.DeptNo
                        select new { emp.EmpNo, emp.DeptNo, emp.Name, dept.DeptName  };
            foreach (var emp in emps1) {
                Console.WriteLine(emp.EmpNo+ ", " +emp.DeptNo+ ", " +emp.Name );
            }
                        
        }


        static Employee GetEmployee(Employee obj) {
            return obj;
        }
        //Passing function as paramter to get the emp object
        static void Main5() {
            AddRecs();

            //Direct Method Called as Parameter
            var emps1 = lstEmp.Select(GetEmployee);
            foreach (var emp in emps1) {
                Console.WriteLine(emp.EmpNo+ " " +emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Instead passing function as parameter we can use Anonymous Function
            var emps2 = lstEmp.Select(delegate (Employee obj)
            {
                return obj;
            });
            foreach (var emp in emps2) {
                Console.WriteLine(emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Instead using anonymous functions we can use Lambda functions
            var emps3 = lstEmp.Select(emp => emp);
            foreach(var emp in emps3) {
                Console.WriteLine(emp.Name);    
            }

        }

        //
        static void Main6() {

            //First
            AddRecs();
            var emps1 = lstEmp.Select(emp => emp);
            foreach (var emp in emps1) {
                Console.WriteLine(emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Second
            var emps2 = lstEmp.Where(emp => emp.Basic > 10000);
            foreach (var emp in emps2) {
                Console.WriteLine(emp.EmpNo+ " " +emp.DeptNo+ " " +  emp.Basic +" "+emp.Name  );
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Third
            var emps3 = lstEmp.Where(emp => emp.Basic > 11000).Select(emp => emp);
            foreach (var emp in emps3) {
                Console.WriteLine(emp.Name + "  " +emp.Basic);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();



            //Fourth
            var emps4 = lstEmp.Where(emp => emp.Basic > 10000).Select(emp => emp.Name).OrderByDescending(emp => emp.Length);
            foreach (var emp in emps4)
            {
                Console.WriteLine(emp);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Fifth (Not possible)
            //var emps5 = lstEmp.Select(emp => emp.Name ).Where(emp => emp.Basic > 10000);
            //foreach (var emp in emps5)
            //{
            //    Console.WriteLine(emp.Name + "  " + emp.Basic);
            //}


            //Sixth JOINS
            Console.WriteLine("Sixth");
            var emps6 = lstEmp.Join(lstDept, emp => emp.DeptNo, dept => dept.DeptNo, (emp, dept) => emp);
            foreach (var emp in emps6)
            {
                Console.WriteLine(emp.EmpNo + " " +emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Seventh
            var emps7 = lstEmp.Join(lstDept, emp => emp.DeptNo, dept => dept.DeptNo, (emp, dept) => new { emp.Name, emp.DeptNo });
            foreach (var emp in emps7) {
                Console.WriteLine(emp.DeptNo+ " " +emp.Name + " "  );
            }


            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            //Eight
            var emps8 = lstEmp.Join(lstDept, emp => emp.DeptNo, dept => dept.DeptNo, (emp, dept) => emp);
            foreach (var emp in emps8)
            {
                Console.WriteLine(emp.DeptNo + " " + emp.Name + " " +emp.Gender);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();
            Console.WriteLine("Ninth");
            //ninth
            var emps9 = lstEmp.Join(lstDept, emp => emp.DeptNo, dept => dept.DeptNo, (emp,dept) => dept);
            foreach (var dept in emps9) {
                Console.WriteLine(dept.DeptNo + " " +dept.DeptName);
            }


            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            var emps10 = lstEmp.OrderByDescending(emp => emp.Name);
            foreach (var emp in emps10)
            {
                Console.WriteLine(emp.EmpNo + " " +emp.Name);
            }

            Console.WriteLine();
            Console.WriteLine("=======================================================");
            Console.WriteLine();

            var emps11 = lstEmp.OrderBy(emp => emp.Basic);
            foreach (var emp in emps10)
            {
                Console.WriteLine(emp.EmpNo + " " + emp.Name);
            }

        }

        static void Main7() {
            AddRecs();

            //De
            var emps = from emp in lstEmp select emp;
            foreach (var emp in emps) {
                Console.WriteLine(emp.Name);
            }

            Console.WriteLine("+++++++++++++++++++++");

            lstEmp.RemoveAt(0);
            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name);
            }
            Console.WriteLine("+++++++++++++++++++++");

            lstEmp.Add(new Employee { EmpNo = 9, Name = "Rushabh", Basic = 10000, DeptNo = 40, Gender = "M" });
            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name);
            }
        }

        static void Main() {
            AddRecs();

           
            var emps = from emp in lstEmp select emp;
            //immediate execution
            emps = emps.ToList();

            Console.WriteLine();
            lstEmp.RemoveAt(0);
            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name + "," + emp.EmpNo);
            }
            Console.WriteLine();
            lstEmp.Add(new Employee { EmpNo = 9, Name = "New", Basic = 11000, DeptNo = 40, Gender = "F" });
            foreach (var emp in emps)
            {
                Console.WriteLine(emp.Name + "," + emp.EmpNo);
            }
            Console.ReadLine();
        }

        public static void AddRecs()
        {
            lstDept.Add(new Department { DeptNo = 10, DeptName = "SALES" });
            lstDept.Add(new Department { DeptNo = 20, DeptName = "MKTG" });
            lstDept.Add(new Department { DeptNo = 30, DeptName = "IT" });
            lstDept.Add(new Department { DeptNo = 40, DeptName = "HR" });

            lstEmp.Add(new Employee { EmpNo = 1, Name = "Vikram", Basic = 10000, DeptNo = 10, Gender = "M" });
            lstEmp.Add(new Employee { EmpNo = 2, Name = "Vikas", Basic = 11000, DeptNo = 10, Gender = "M" });
            lstEmp.Add(new Employee { EmpNo = 3, Name = "Abhijit", Basic = 12000, DeptNo = 20, Gender = "M" });
            lstEmp.Add(new Employee { EmpNo = 4, Name = "Mona", Basic = 11000, DeptNo = 20, Gender = "F" });
            lstEmp.Add(new Employee { EmpNo = 5, Name = "Shweta", Basic = 12000, DeptNo = 20, Gender = "F" });
            lstEmp.Add(new Employee { EmpNo = 6, Name = "Sanjay", Basic = 11000, DeptNo = 30, Gender = "M" });
            lstEmp.Add(new Employee { EmpNo = 7, Name = "Arpan", Basic = 10000, DeptNo = 30, Gender = "M" });
            lstEmp.Add(new Employee { EmpNo = 8, Name = "Shraddha", Basic = 11000, DeptNo = 40, Gender = "F" });
        }
    }

    public class Department { 
        public int DeptNo { get; set; }
        public string DeptName { get; set; }
    }

    public class Employee { 
        public int EmpNo { set; get; }
        public string Name { set; get; }
        public decimal Basic { set; get; }
        public int DeptNo { get; set; }
        public string Gender { set; get; }
    }

}
