﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandlerPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 c = new Class1();

            c.InvalidP1 += C_InvalidP1;

            Console.WriteLine("Ste value of the P1 Property : ");
            c.P1 = Convert.ToInt32(Console.ReadLine());

            Console.ReadLine();
        }

        private static void C_InvalidP1()
        {
            Console.WriteLine("Invalid P1 Occurred..!");
        }
    }

    //step1 : create delegate class
    public delegate void InvalidP1EventHandler();

    class Class1 {

        //Step 2 : create object of event of delegate class type.
        public event InvalidP1EventHandler InvalidP1;

        private int p1;
        public int P1 {
            get { return p1; }
            set {
                if(value < 100)
                    p1 = value;
                else
                {
                    ///step 3 : call the event object
                    InvalidP1();
                    //Console.WriteLine("Invalid value..!!");
                }
            }
        }
    }
}
