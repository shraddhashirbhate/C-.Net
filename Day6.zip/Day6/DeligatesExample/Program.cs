﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeligatesExample
{

    //step 1: create a delegate Class having the same signature as the function to call
    public delegate void Del1();
    public delegate void Del2(int a);


    class Program
    {
        static void Main1(string[] args)
        {
            //Display();

            //step 2: create a Delegate object passing the function name as a parameter
            Del1 objdel = new Del1(Display);
            Del2 objdel1 = new Del2(Display1);

            //step 3: call the function via the delegate object
            objdel();
            objdel1(100);
            

            Console.ReadLine();
        }

        static void Main2(string[] args)
        {
            //Display();

            //step 2: create a Delegate object passing the function name as a parameter
            Del1 objdel = new Del1(Display);
            Del1 objdel2 = new Del1(show);

            Del1 obj;
            obj = new Del1(Display);
            obj = new Del1(show);

            Del2 objdel1 = new Del2(Display1);

            //step 3: call the function via the delegate object
            objdel();
            objdel2();
            objdel1(100);


            Console.ReadLine();
        }


        static void Main3(string[] args)
        {
            //Display();

            //step 2: create a Delegate object passing the function name as a parameter
            Del1 objdel = new Del1(Display);
            Del1 objdel2 = new Del1(show);

            Del1 obj;
            obj = new Del1(Display);
            obj();
            Console.WriteLine("==========================");
            //If there is += then there should also be -=
            obj += new Del1(show);
            obj();
            Console.WriteLine("==========================");
            obj -= new Del1(show);
            obj();
            Console.WriteLine("==========================");
            Del2 objdel1 = new Del2(Display1);
            Console.WriteLine("==========================");
            //step 3: call the function via the delegate object
            objdel();
            Console.WriteLine("==========================");
            objdel2();
            Console.WriteLine("==========================");
            objdel1(100);


            Console.ReadLine();
        }

        static void Main4(string[] args)
        {
            //Display();

            //step 2: create a Delegate object passing the function name as a parameter
            Del1 objdel = new Del1(Display);
            Del1 objdel2 = new Del1(show);

            //We can directly give this
            Del1 o;
            o = Display;
            o();

            o += show;
            o();



            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            //Display();

            //step 2: create a Delegate object passing the function name as a parameter

           Del1 objDel =  (Del1)Delegate.Combine(new Del1(Display), new Del1(show), new Del1(Display));
            objDel();
            Console.WriteLine();
            Console.WriteLine();

           // Delegate.Remove();

            Console.ReadLine();
        }

        static void Display() {
            Console.WriteLine("Display..!!");
        }


        static void show()
        {
            Console.WriteLine("show..!!");
        }

        static void Display1(int i)
        {
            Console.WriteLine("I value : " +i);
            Console.WriteLine("Display..!!");
        }
    }
}
