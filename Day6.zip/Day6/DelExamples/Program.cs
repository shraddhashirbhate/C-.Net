﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelExamples
{
    //step 1: create a delegate
    public delegate int Del1();
    public delegate int Del2(int a, int b);

    class Program
    {
        static void Main1(string[] args)
        {

            //step 2: create an object of delegate class.
            Del2 o = Add;
            Del2 o1 = new Del2(Add); //Both are same


            //Step 3: calling a function
            Console.WriteLine(o(10, 20));

            //try multicast delegates with parameters and a return value

          
        }

        static void Main2(string[] args)
        {

            //step 2: create an object of delegate class.
            Del2 o = Class2.Add;
            Del2 o1 = new Del2(Add); //Both are same


            //Step 3: calling a function
            Console.WriteLine(o(10, 20));

            //try multicast delegates with parameters and a return value


        }

        static void Main3(string[] args)
        {

            //step 2: create an object of delegate class.
            Class3 obj = new Class3();
            Del2 o = obj.Add;
            Del2 o1 = new Del2(Add); //Both are same


            //Step 3: calling a function
            Console.WriteLine(o(10, 20));

            //try multicast delegates with parameters and a return value


        }

        static void Main(string[] args)
        {
            Console.WriteLine(PassMethodToCallAsParameter(Add, 20, 10));
            Console.WriteLine(PassMethodToCallAsParameter(subtract, 20, 10));
            Console.WriteLine(PassMethodToCallAsParameter(Multiply, 20, 10));
            Console.ReadLine();
        }

        static void Display()
        {
            Console.WriteLine("Display..!!");
        }


        static void show()
        {
            Console.WriteLine("show..!!");
        }

        static int Add(int a, int b)
        {
            return a + b;
        }
        static int subtract(int a, int b)
        {
            return a - b;
        }

        static int Multiply(int a, int b)
        {
            return a * b;
        }

        static int PassMethodToCallAsParameter(Del2 objDelAdd, int a, int b)
        {
            return objDelAdd(a, b);
        }
    }

    public class Class2 {
        public static int Add(int a, int b)
        {
            return a + b;
        }
    }

    public class Class3
    {
        public  int Add(int a, int b)
        {
            return a + b;
        }
    }
}
