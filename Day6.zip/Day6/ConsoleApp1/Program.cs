﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    { 
        public delegate void Del1();

        public delegate int Del2(int a, int b);

        public delegate int Del3(int a, int b, int c);
        static void Main1(string[] args)
        {
            Del1 obj;

            //Using the Longer syntax
            Console.WriteLine("Using Longer Syantax");
            obj = new Del1(Display);
            obj();

            obj = new Del1(Show);
            obj();

            Console.WriteLine("====================");

            //Using smaller syntax..Directly giving the name of the function 
            Console.WriteLine("Using smaller Syntax");
            obj = Display;
            obj();

            obj = Show;
            obj();

            Console.WriteLine("====================");

            Console.WriteLine("Using Multicast Delegate..");
            obj = Display;
            obj();
            Console.WriteLine();
            obj = Show;
            obj();
            Console.WriteLine();
            obj += Display;
            obj();
            Console.WriteLine();
            obj += Display;
            obj();
           /* Console.WriteLine();
            obj = Show;
            obj();*/

            Console.WriteLine();
            obj -= Show;
            obj();

            Console.WriteLine();
            obj -= Display;
            obj();



            Console.ReadLine();
        }

        static void Main2()
        {
            Del1 obj;
            
            //It is similar to +=
            obj  = (Del1)Delegate.Combine(new Del1(Display), new Del1(Show), new Del1(Display));
            obj();

            Console.WriteLine();
            Console.WriteLine("===================");
            Console.WriteLine();

            obj = (Del1)Delegate.Remove(obj, new Del1(Show));
            obj();

            Console.WriteLine();
            Console.WriteLine("===================");
            Console.WriteLine();


            obj = (Del1)Delegate.Combine(new Del1(Display), new Del1(Show), new Del1(Display), new Del1(Show), new Del1(Show));
            obj();

            Console.WriteLine();
            Console.WriteLine("===================");
            Console.WriteLine();

            //removeAll will remove all the occurrance of the Display 
            obj = (Del1)Delegate.RemoveAll(obj, new Del1(Display));
            obj();

            Console.ReadLine();

        }

        static void Main3() {

            //we can either use this 
            Del2 obj;

            obj = new Del2(Add);
            Console.WriteLine(obj(5, 6));

            Console.WriteLine();
            Console.WriteLine("===================");
            Console.WriteLine();

            //We can use the shorter syntax
            obj = Add;
            Console.WriteLine(obj(8, 10));

            Console.ReadLine();
        }

        /*What if the method is not present in the same class?
         *  Call the function using Class name directly
         */
        static void Main4() {
            Del3 obj;
            obj = Class1.Add;
            Console.WriteLine(obj(5, 2, 3)); 
            Console.ReadLine();

        }

        /*What if the function is not present in the same class and is not static 
         * create the object of the clas and then call the function
         */
        static void Main5() {
            Del3 obj;
            Class1 c = new Class1();
            obj = c.Addition;
            Console.WriteLine(obj(8,7,5));

        }


        /*  Application of the DELEGATEs
            1. Passing the function to be called as a parameter
         */
        static void Main() {
           
            Console.WriteLine(PassFunctionToCallAsParameter(Add, 5,2));

            Console.WriteLine(PassFunctionToCallAsParameter(Sub, 5, 2));

            Console.WriteLine(PassFunctionToCallAsParameter(Mul, 5, 2));
            Console.ReadLine();

        }

        static int Add(int a, int b)
        {
            return a + b;
        }

        static int Sub(int a, int b)
        {
            return a - b;
        }

        static int Mul(int a, int b)
        {
            return a * b;
        }

        static int PassFunctionToCallAsParameter(Del2 obj, int a, int b) {
            return obj(a, b);
        }

        static void Display() {
            Console.WriteLine("Display..!!");
        }

        static void Show() {
            Console.WriteLine("Show..!!");
        }
    }

    public class Class1 {
        public static int Add(int a, int b, int c) {
            return a + b + c;
        }

        public int Addition(int a, int b, int c)
        {
            return a + b + c;
        }
    }
}
