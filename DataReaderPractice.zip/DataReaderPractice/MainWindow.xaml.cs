﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace DataReaderPractice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //NextReader
        private void btnDataReader_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Students";
            SqlDataReader dr = cmd.ExecuteReader();

            lblText.Items.Add("Students Details : ");
            while (dr.Read()) {
                lblText.Items.Add("   " + dr["StdID"] + "   " + dr["Name"]);
            }

            dr.Close();
            cn.Close();

        }


        //Mars
        private void btnMars_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False; MultipleActiveResultSets=True";
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Course";

            SqlCommand cmd1 = new SqlCommand();
            cmd1.Connection = cn;
            cmd1.CommandType = CommandType.Text;


            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read()) {
                lblText.Items.Add(dr["CrsName"]);                    
                cmd1.CommandText = "select * from Students where CourseID = " + dr["CourseID"];                
                SqlDataReader dr1 = cmd1.ExecuteReader();
                while (dr1.Read()) {
                    lblText.Items.Add("    " +dr1["StdID"] + "   " + dr1["Name"]);
                }

                dr1.Close();

            }


            dr.Close();

        }

        private void NextReader_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";
            cn.Open();
           
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            SqlDataReader dr = cmd.ExecuteReader();           
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Course; Select * from Students where CourseID = "+dr["CourseID"] ;
          

            lblText.Items.Add("Course Details : ");         
            while (dr.Read()) {
                lblText.Items.Add("    " + dr["Name"]);
            }


            dr.NextResult();


           lblText.Items.Add("Setudents Details : ");
            while (dr.Read())
            {
                lblText.Items.Add("    " + dr["CrsName"]);
            }

            dr.NextResult();

            lblText.Items.Add("Employees Details : ");
            while (dr.Read())
            {
                lblText.Items.Add("    " + dr["Name"]);
            }

         


            dr.Close();
            cn.Close();


        }
    }
}
