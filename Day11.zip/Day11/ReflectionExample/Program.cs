﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;


namespace ReflectionExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly asm = Assembly.LoadFrom(@"C:\Users\SHRADDHA\Desktop\.Net CDAC\Day11");

            Console.WriteLine(asm.FullName);
            Console.WriteLine(asm.GetName().Name);
            asm.GetType

            Console.ReadLine();
        }
    }
}
