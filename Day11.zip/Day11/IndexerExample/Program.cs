﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1(5, 0);
            obj[0] = 100;
            obj[1] = 200;
            obj[2] = 300;
            obj[3] = 400;
            obj[4] = 500;

            Console.WriteLine(obj[0]);
            Console.ReadLine();
        }
    }

    public class Class1 {
        int[] arr;
        int startpos;

        public Class1(int size, int startpos) {
            arr = new int[size];
            this.startpos = startpos;
        }

        public int this[int index] {
            set {
                arr[index] = value;
            }
            get {
                return arr[index];
            }
        }
    }
}
