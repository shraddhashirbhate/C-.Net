﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Que1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee o1 = new Employee("Amol", 123465, 10);
            o1.Display();
            Console.WriteLine("");
            Employee o2 = new Employee("ALka", 123465);
            o2.Display();
            Console.WriteLine("");
            Employee o3 = new Employee("Amol");
            Employee o4 = new Employee();

            Employee o5 = new Employee();
            Employee o6 = new Employee();
            Employee o7 = new Employee();
            Console.WriteLine(o1.EmpNo);
            Console.WriteLine(o2.EmpNo); 
            Console.WriteLine(o3.EmpNo);
            Console.WriteLine(o4.EmpNo);
            Console.WriteLine(o5.EmpNo);
            Console.WriteLine(o6.EmpNo);
            Console.WriteLine(o7.EmpNo);

           
            Console.WriteLine(o3.EmpNo); 
            Console.WriteLine(o2.EmpNo); 
            Console.WriteLine(o1.EmpNo); 

        }
    }

    public class Employee {
        private string name;
        public string Name {
            set 
            {
                if (value != "")
                {
                    name = value;
                }
                else {
                    Console.WriteLine("Blank name entered..!!");
                }         
            }
            get { return name;  }
        }

        private static int lastEmpNo = 0; 
        private int empNo;
        public int EmpNo {
            get { return empNo; }
        }

        private decimal basic;
        private decimal Basic {
            set {
                if (value >= 10000 && value <= 5000000)
                    basic = value;
                else
                    Console.WriteLine("Entered value is out of range..!!");
            }
            get { return basic; }
        }

        private short deptNo;
        public short DeptNo {
            set {
                if (value < 1)
                    Console.WriteLine("Department number cannot be less than 1");
                else
                    deptNo = value;
            }
            get { return deptNo;  }
        }


        public decimal GetNetSalary(decimal basic) {
            return basic * 12;
        }


        public Employee() {
            empNo = ++lastEmpNo;
            name = "Shraddha Shirbhate";
            basic = 2000;
            deptNo = 1;
        }
        public Employee(string name) {
            empNo = ++lastEmpNo;
            this.name = name; 
            basic = 2000;
            deptNo = 1;
        }

        public Employee(string name, decimal basic) {
            empNo = ++lastEmpNo;
            this.name = name;
            this.basic = basic;
            deptNo = 1;
        }

        public Employee(string name, decimal basic, short deptNo)
        {
            empNo = ++lastEmpNo;
            this.name = name;
            this.basic = basic;
            this.deptNo = deptNo;
        }

        public void Display() {
            Console.WriteLine("EmpId : " +empNo);
            Console.WriteLine("EmpName : " +name);
            Console.WriteLine("Basic : " +basic);
            Console.WriteLine("DeptNo : " +deptNo);
        }
    }
}
