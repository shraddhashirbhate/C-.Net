﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*1.    Create an array of Employee class objects
        Accept details for all Employees
        Display the Employee with highest Salary
        Accept EmpNo to be searched. Display all details for that employee.
*/

namespace Que1
{
    class Program
    {        
            static void Main()
            {

                Console.Write("Enter size of Array : ");
                int s = Convert.ToInt32(Console.ReadLine());
                Employee[] emp = new Employee[s];

            //Enter Employee records
            for (int i = 0; i < emp.Length; i++) {
                Console.Write("Enter name of Employee : ");
                string name = Convert.ToString(Console.ReadLine());

                Console.Write("Enter Basic Salary : ");
                decimal basic = Convert.ToDecimal(Console.ReadLine());
                
                Employee e = new Employee(name, basic);
                emp[i] = e;
            }

            Console.WriteLine();
            Console.WriteLine();

            //Display Employee records
            Console.WriteLine("Employee Records are as follows : ");
            foreach (Employee e in emp)
            {
                Console.WriteLine("Employee Number : " +e.EmpNo);
                Console.WriteLine("Employee Name : " +e.Name);
                Console.WriteLine("Basic Salary : " +e.Basic);
            }
            Console.WriteLine();
            Console.WriteLine();

            //Highest salary
            decimal highestSalary = emp[0].Basic;
            foreach(Employee e in emp) {
                if (e.Basic > highestSalary)
                    highestSalary = e.Basic;
            }
            Console.WriteLine("Highest Salary : " +highestSalary);

            Console.WriteLine();
            Console.WriteLine();

            //Serach Employee by their empNo
            Console.WriteLine("Enter the Employee to be searched : ");
            int search = Convert.ToInt32(Console.ReadLine());
            foreach(Employee e in emp) {
                if (search == e.EmpNo)
                {
                    Console.WriteLine("Employee is present");
                    Console.WriteLine("EmpNo :  " + e.EmpNo + "  Name : " + e.Name + "  Basic Salary : " + e.Basic);
                }
    
            }

            }
    }

    public class Employee {
        private int empNo;
        private static int lastEmpNo = 0; 
        public int EmpNo {
            set { empNo = ++lastEmpNo;  }
            get { return empNo;  }
        }
        private string name;
        public string Name {
            set {
                if (value != "")
                    name = value;
                else
                    Console.WriteLine("Balnk name cannot be enetred..!!");
            }
            get { return name; }
        }
        private decimal basic;
        public decimal Basic {
            set {
                if (value >= 10000 && value <= 500000)
                    basic = value;
                else
                    Console.WriteLine("Entered value is ou of this range..!!");
            }
            get { return basic;  }
        }

        public Employee(string name, decimal basic) {
            empNo = ++lastEmpNo;
            this.name = name;
            this.basic = basic;
        }

    }
}
