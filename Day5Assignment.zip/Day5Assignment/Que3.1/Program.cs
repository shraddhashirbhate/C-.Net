﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    3. Create a struct Student with the following properties. Put in appropriate validations.
    string Name
    int RollNo
    decimal Marks
    Create a parameterized constructor.
    Create an array to accept details for 5 students
 */

namespace Que3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter size of student Array : ");
            int s = Convert.ToInt32(Console.ReadLine());
            Student[] st = new Student[s];

            for (int i = 0; i < st.Length; i++) {
                Console.Write("Enter Name of the Student : ");
                string name = Convert.ToString(Console.ReadLine());

                Console.Write("Enter Marks of the Student : ");
                int marks = Convert.ToInt32(Console.ReadLine());

                Student stu = new Student(name, marks);
                st[i] = stu;
            }

            Console.WriteLine();
            Console.WriteLine();
            //Display student information
            foreach(Student stud in st) {
                Console.WriteLine("Roll No : " +stud.RollNo);
                Console.WriteLine("Name : " +stud.Name);
                Console.WriteLine("Marks : " +stud.Marks);
            }
        }
    }

    struct Student
    {
        private int rollNo;
        private static int lastRollNo = 0; 
        public int RollNo
        {
            set {
                rollNo = ++lastRollNo;
            }
            get { return rollNo;  }
        }

        private string name;
        public string Name {
            set {
                if (value != "")
                    name = value;
                else
                    Console.WriteLine("Name cannot be left blank..!!");
            }
            get { return name;  }
        }
        private int marks;
        public int Marks
        {
            set { marks = value; }
            get { return marks;  }

        }


        public Student(string name, int marks) {
            rollNo = ++lastRollNo;
            this.name = name;
            this.marks = marks;
        }

    }
}
