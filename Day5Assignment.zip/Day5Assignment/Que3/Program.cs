﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Practice
{
    class Program
    {
        static void Main1(string[] args)
        {
            //One DImensional Array
            int[] a = new int[5];

            for (int i = 0; i < a.Length; i++) {
                Console.Write("Enter element for {0} row : ", i);
                a[i] = Convert.ToInt32(Console.ReadLine());
            }

            foreach(int o in a){
                Console.WriteLine("ELement are : " +o);
            }
        }

        static void Main2() {

            //One DImensional String array
            string[] a = new string[5];
            for (int i = 0; i < a.Length; i++) {
                Console.Write("Enter element for {0} position : ", i);
                a[i] = Convert.ToString(Console.ReadLine());
            }

            for (int i = 0; i < a.Length; i++) {
                Console.WriteLine("Element at position {0} is : {1} ",i, a[i]);
            }
        }

        static void Main3() {

            //2 Dimensional Array
            int[,] a = new int[2, 3];

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a.GetLength(1); j++) {
                    Console.Write("Enter element at {0}{1} index : ", i, j );
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine();
            Console.WriteLine();

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a.GetLength(1); j++) {
                    Console.WriteLine("Element at {0}{1} position is : {2}", i, j, a[i,j]);
                }
                Console.WriteLine();
            }
        }

        static void Main4() {
            int[][] a = new int[4][];
            a[0] = new int[3];
            a[1] = new int[2];
            a[2] = new int[4];
            a[3] = new int[3];

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a[i].GetLength(0); j++) {
                    Console.Write("Enter elements at {0}{1} position : ", i, j);
                    a[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a[i].GetLength(0); j++) {
                    Console.WriteLine("Element at {0}{1} position is : {2}  ", i, j, a[i][j]);
                }
            }
           
        }


        static void Main5() {
            string[][] a = new string[3][];
            a[0] = new string[2];
            a[1] = new string[3];
            a[2] = new string[4];

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a[i].GetLength(0); j++) {
                    Console.Write("Enter element at {0}{1} position : ", i,j);
                    a[i][j] = Convert.ToString(Console.ReadLine());
                }
            }

            Console.WriteLine();
            Console.WriteLine();

            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a[i].GetLength(0); j++) {
                    Console.Write( a[i][j] + " ");
                }
                Console.WriteLine();
            }

        }

        static void Main6() {
            Console.Write("Enter ROW value : ");
            int r = Convert.ToInt32(Console.ReadLine());
            int[][] a = new int[r][];

            Console.WriteLine("Enter COLUMN Values for each row : ");
            for (int i = 0; i < r; i++) {
                Console.Write("Enter column for {0}th Row : ",i+1);
                int c = Convert.ToInt32(Console.ReadLine());
                a[i] = new int[c]; 
            }

            //Enter Elements in the 2D array
            for (int i = 0; i < a.GetLength(0); i++) {
                for (int j = 0; j < a[i].Length; j++) {
                    Console.Write("Enter element for {0}{1} Position : ", i,j);
                    a[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            //Display the elements
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write(a[i][j] + " ");                   
                }
                Console.WriteLine("");
            }


        }

        static void Main()
        {
            Console.Write("Enter ROW value : ");
            int r = Convert.ToInt32(Console.ReadLine());
            int[][][] a = new int[r][][];

            Console.WriteLine("Enter COLUMN Values for each row : ");
            for (int i = 0; i < r; i++)
            {
                Console.Write("Enter subject fro Each Student : ");
                int s = Convert.ToInt32(Console.ReadLine());               
                for (int j = 0; j < s; j++) {
                    Console.Write("Enter column for {0}th Row : ", i + 1);
                    int c = Convert.ToInt32(Console.ReadLine());
                    a[i][j] = new int[c];
                }                
            }

            //Enter Elements in the 3D array
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write("Enter student for {0} batch and {1} Position : ", i + 1, j + 1);
                    //a[i][j] = Convert.ToInt32(Console.ReadLine());

                    for (int k = 0; k < a[j].Length; k++) {
                        Console.Write("Enter element for {0}{1} Position : ", i, j);
                        a[i][j][k] = Convert.ToInt32(Console.ReadLine());
                    }
                    
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            //Display the elements
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write(a[i][j] + " ");
                }
                Console.WriteLine("");
            }


        }

    }
}
