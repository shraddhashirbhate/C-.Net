﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*       2. CDAC has certain number of batches. each batch has certain number of students
         accept number of batches from the user. for each batch accept number of students.
         create an array to store mark for each student. 
         accept the marks.
         display the marks.*/

namespace Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Accepts number of batches
            Console.Write("Enter number of batches in CDAC: ");
            int b = Convert.ToInt32(Console.ReadLine());
            int[][] a = new int[b][];

            //Accept number of students in each batch
            Console.WriteLine("Enter number of students in the respective batches : ");
            for (int j = 0; j < b; j++)
            {
                Console.Write("Students in batch {0} : ", j + 1);
                int k = Convert.ToInt32(Console.ReadLine());
                a[j] = new int[k];
            }

            //Make Entries of the students
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write("Enter element for {0}{1} position : ", i, j);
                    a[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }

           // int[][] m = new int[b][][3];

            //Display students
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write(a[i][j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
