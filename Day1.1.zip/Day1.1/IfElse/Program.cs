﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {                 
            Console.WriteLine("IF-ELSE Demo");
            Console.WriteLine();
            Console.WriteLine("Enter any number : ");
            int i = Convert.ToInt32(Console.ReadLine());
            if (i % 2 == 0)
            {
                Console.WriteLine("Number is Even");
            }
            else {
                Console.WriteLine("Number is Odd");
            }

            Console.WriteLine("===============================================");
            Console.WriteLine("SWITCH-CASE Demo");
            Console.WriteLine();
            SwitchCase.Program.Calculator();

            Console.WriteLine("===============================================");
            Console.WriteLine("FOR-LOOP Demo");
            Console.WriteLine();
            SwitchCase.Program.Table();

            Console.WriteLine("===============================================");
            Console.WriteLine("LABEL Demo");
            Console.WriteLine();
            Pragram1 p = new Pragram1();
            p.LabelDemo();
        }
    }

    class Pragram1 {
        public void LabelDemo() {
                l1:
                    Console.WriteLine("Number is less than 10");
            Console.WriteLine("ENter any number : ");
            int l = Convert.ToInt32(Console.ReadLine());

            if (l < 10) {
                goto l1;

            }               
            else
            {
                Console.WriteLine("Entered number is : " + l);
            }
                

        }
        
    }
}

namespace SwitchCase {

    class Program { 
        public static void Calculator()
        {
            Console.WriteLine("Enter first number : ");
            int i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number : ");
            int j = Convert.ToInt32(Console.ReadLine());
            int result = 0;

            Console.WriteLine("Enter your Choice.\n" + "A. Addition\n" + "B. Substraction\n" + "C. Multiplication\n" + "D. Division");
            char op = Convert.ToChar(Console.ReadLine());

            switch (op) {
                case'A':
                    Console.WriteLine(result = i + j);
                    break;

                case 'B':
                    Console.WriteLine(result = i - j);
                    break;
                case 'C':
                    Console.WriteLine(result = i * j);
                    break;
                case 'D':
                    Console.WriteLine(result = i / j);
                    break;
                case 'E': 
                    break;

            }
        }

        public static void Table() {
            Console.WriteLine("Enter any number : ");
            int a = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++) {
                Console.WriteLine(a + " * " + i + " = " + a * i);
            }
        }
    }
        
}
